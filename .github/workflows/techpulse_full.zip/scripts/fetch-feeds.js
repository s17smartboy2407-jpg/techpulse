// Node script to fetch multiple RSS feeds/APIs, normalize, dedupe, and output data/articles.json
// Usage: node scripts/fetch-feeds.js
const fs = require('fs');
const path = require('path');
const Parser = require('rss-parser');
const fetch = require('node-fetch');

const parser = new Parser({timeout: 15000});

const outPath = path.join(__dirname, '..', 'data', 'articles.json');
const sources = [
  { id: 'techcrunch', title: 'TechCrunch', url: 'https://techcrunch.com/feed/' },
  { id: 'verge', title: 'The Verge', url: 'https://www.theverge.com/rss/index.xml' },
  { id: 'ars', title: 'Ars Technica', url: 'http://feeds.arstechnica.com/arstechnica/index' },
  { id: 'engadget', title: 'Engadget', url: 'https://www.engadget.com/rss.xml' },
  { id: 'reddit_technology', title: 'Reddit /r/technology', url: 'https://www.reddit.com/r/technology/.rss' },
  { id: 'hn', title: 'Hacker News', url: 'https://hnrss.org/frontpage' }
];

async function fetchAll(){
  const items = [];
  for(const s of sources){
    try {
      console.log('Fetching', s.title);
      const feed = await parser.parseURL(s.url);
      feed.items.slice(0,80).forEach(it=>{
        const url = it.link || it.guid || it.id || '';
        const title = it.title || '';
        const pub = it.pubDate || it.isoDate || it.published || null;
        const excerpt = (it.contentSnippet || it.summary || '').replace(/[\n\r]+/g,' ').trim().slice(0,300);
        let image = null;
        if(it.enclosure && it.enclosure.url) image = it.enclosure.url;
        const tags = (it.categories || []).slice(0,5);
        items.push({title, url, publishedAt: pub, excerpt, image, source: s.title, sourceId: s.id, tags});
      });
    } catch(e){
      console.error('Error fetching', s.title, e.message);
      // continue
    }
  }

  // dedupe by URL and title
  const seen = new Set();
  const dedup = [];
  items.sort((a,b)=> new Date(b.publishedAt || 0) - new Date(a.publishedAt || 0));
  for(const it of items){
    const key = (it.url || it.title || '').replace(/\/+$/,'').toLowerCase();
    if(!key) continue;
    if(seen.has(key)) continue;
    seen.add(key);
    dedup.push(it);
  }

  // limit to 200-1000 items
  const final = dedup.slice(0,800);

  const out = {generatedAt: (new Date()).toISOString(), count: final.length, articles: final};
  fs.mkdirSync(path.dirname(outPath), {recursive:true});
  fs.writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8');
  console.log('Wrote', outPath, 'items:', final.length);
}

fetchAll();
