
# TechPulse — Auto-updating Tech News Site (Ready-to-deploy)

This repository contains a static frontend and a scheduled fetcher that aggregates tech headlines from RSS feeds and writes `data/articles.json`.

## How it works
- `scripts/fetch-feeds.js` fetches RSS feeds and outputs `data/articles.json`.
- A GitHub Actions workflow (`.github/workflows/refresh-feed.yml`) runs hourly and commits the generated JSON to the repo.
- The static site (`index.html`) reads `/data/articles.json` and renders a fast feed. Links open at original publishers (no copied content).

## Deployment (free)
1. Create a GitHub repository and push this project.
2. In the repo, go to **Actions** and enable the workflow. It will run hourly and produce `data/articles.json`.
3. Host the `index.html` on GitHub Pages or Netlify. If using GitHub Pages, enable Pages in repo settings (branch: main, folder: root).

## Customize sources
Edit `scripts/fetch-feeds.js` `sources` array to add/remove feeds. Use RSS URLs. For APIs (e.g., NewsAPI) you can add a fetch and normalize the response.

## Notes & legal
- This project aggregates headlines and short excerpts and *links* back to original publishers. Do not copy full articles without permission.
- Some feeds may block frequent requests; adjust schedule if needed.

## Quick start (locally)
```bash
npm install
node scripts/fetch-feeds.js
# view data/articles.json
```
